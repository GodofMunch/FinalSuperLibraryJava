create trigger ISBN_TRG
  before insert
  on BOOK
  for each row
DECLARE
  v_isbn_count numeric(3,0);
  v_error_count varchar2(100);
BEGIN
  v_error_count := 'ISBN: '|| :NEW.ISBN || ' is already in the system. Perhaps you mean to update NoInStock';
  
  SELECT COUNT(ISBN) INTO v_isbn_count
  FROM Book
  WHERE (ISBN = :NEW.ISBN);
  
  IF v_isbn_count <> 0 THEN
    RAISE_APPLICATION_ERROR(-20000, v_error_count);
  END IF;
  
END;
/

