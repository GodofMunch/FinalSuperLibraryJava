create trigger EMAIL_TRG
  before insert or update of EMAIL
  on CUSTOMER
  for each row
DECLARE 
  v_email CUSTOMER.EMAIL%TYPE;
  v_errorMessage  varchar2(255);

BEGIN
  v_errorMessage := 'invalid mail format';
  IF(NOT(REGEXP_LIKE(v_email, '^[A-Z0-9._%-]+@[A-Z0-9._%-]+\.[A-Z]{2,4}$')))
  THEN
      RAISE_APPLICATION_ERROR(-20000, v_errorMessage);
  END IF;
END;
/

