create trigger CUSTPASSWORD_TRG
  before insert or update
  on CUSTOMER
  for each row
DECLARE
    v_password CUSTOMER.CUSTPASSWORD%TYPE;
    v_errorLength varchar2(255);
    v_errorCaps varchar2(255);
    v_errorSmall varchar2(255);
    v_errorDigit varchar2(255);
    v_errorSpecial varchar2(255);
    v_errorGeneric varchar2(255);
    
BEGIN
    v_password := :NEW.CUSTPASSWORD;
    v_errorLength := 'NOT LONG ENOUGH';
    v_errorCaps := 'MUST HAVE AT LEAST ONE CAPS';
    v_errorSmall := 'MUST HAVE AT lEAST ONE SMALL';
    v_errorDigit := 'MUST HAVE AT LEAST ONE NUMBER';
    v_errorSpecial := 'MUST HAVE AT LEAST ONE SPECIAL CHARACTER';
    v_errorGeneric := 'Not a valid password';
    
   
IF(NOT(LENGTH (v_password) >=8 AND LENGTH(v_password) <=50))
    THEN
        RAISE_APPLICATION_ERROR(-20000, v_errorLength);
    ELSE
        IF(LENGTH(TRIM(TRANSLATE(v_password, '0123456789', ' ')))<1)
        THEN    
            RAISE_APPLICATION_ERROR(-20001, v_errorDigit);
        ELSE
            IF(LENGTH(TRIM(TRANSLATE(v_password, 'abcdefghijklmnopqrstuvwxyz', ' ')))<1)
            THEN
                RAISE_APPLICATION_ERROR(-20002, v_errorSmall);
            ELSE 
                IF(LENGTH(TRIM(TRANSLATE(v_password, 'ABCDEFGHIJKLMNOPQRSTUVWXYZ', ' ')))<1)
                THEN
                    RAISE_APPLICATION_ERROR(-20003, v_errorCaps);
                ELSE
                    IF(LENGTH(TRIM(TRANSLATE(v_password, '!£$%^&*()_+=-{}][~#@:;<,>.?/|\', ' ')))<1)
                    THEN
                        RAISE_APPLICATION_ERROR(-20004, v_errorSpecial);
                    END IF;
                END IF;
            END IF;
        END IF;
    END IF;
END;
/

