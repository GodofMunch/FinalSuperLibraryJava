create trigger WISHBOOK_TRG
  after update of NOINSTOCK
  on BOOK
  for each row
Declare
	TYPE arrayofnumbers IS TABLE OF NUMBER;
	id_customer arrayofnumbers;
BEGIN
  Select CUSTOMERID BULK COLLECT into id_customer
    From CUSTOMER C
    Where :NEW.ISBN = C.WISHBOOk; 
    FOR i IN 1..id_customer.COUNT LOOP
        INSERT into NOTIFICATION(CUSTOMERID, NOTIFTEXT) Values(id_customer(i), 'Book available now : '+ :NEW.TITLE);
    END LOOP; 
END;
/

