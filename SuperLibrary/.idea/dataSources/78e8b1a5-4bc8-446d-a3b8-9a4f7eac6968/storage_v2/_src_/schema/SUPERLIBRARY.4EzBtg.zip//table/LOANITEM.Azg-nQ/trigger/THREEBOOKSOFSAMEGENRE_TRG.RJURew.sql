create trigger THREEBOOKSOFSAMEGENRE_TRG
  before insert
  on LOANITEM
  for each row
DECLARE
	TYPE arrayofnumbers IS TABLE OF NUMBER;
	v_order_id arrayofnumbers;
BEGIN
  --get all orders by a customer that has made 3 or more orders
  SELECT OrderID BULK COLLECT INTO v_order_id
  FROM Loan
  HAVING COUNT(CustomerID) > 3;
  
  --check these orders to see if a cusomer has rented 3 books of same genre
  FOR i in 1..v_order_id.COUNT LOOP
    NULL;
  END LOOP;
END;
/

