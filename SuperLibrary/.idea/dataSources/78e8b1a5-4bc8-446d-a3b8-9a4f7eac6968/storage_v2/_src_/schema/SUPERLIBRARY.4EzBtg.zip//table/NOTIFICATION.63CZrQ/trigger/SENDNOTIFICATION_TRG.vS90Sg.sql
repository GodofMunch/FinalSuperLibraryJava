create trigger SENDNOTIFICATION_TRG
  after insert
  on NOTIFICATION
  for each row
Declare 
mail_address varchar2(50);
forename varchar2(50);
BEGIN
    Select FORENAME into forename 
    from  Customer
    Where CustomerID = :NEW.CustomerID;
    Select email into mail_address
    from Customer
    Where CustomerID = :NEW.CustomerID 
    AND  :NEW.NOTIFSENT = 'Y';
    
    --UTL_MAIL.send(sender     => 'daveosullivan90@gmail.com',
    --               recipients => mail_address,
    --                cc         => '',
    --                bcc        => '',
    --                subject    => 'Book that you may enjoy',
    --                   message    => :NEW.NotifText);
    
    DBMS_OUTPUT.put_line('Email should be send if not :');
    DBMS_OUTPUT.put_line('Hey ' || forename || ', here some books that you may enjoy!' );
END;
/

